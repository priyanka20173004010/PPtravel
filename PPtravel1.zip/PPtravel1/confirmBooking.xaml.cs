﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Data;
using System.Data;

namespace PPtravel1
{
    /// <summary>
    /// Interaction logic for confirmBooking.xaml
    /// </summary>
    public partial class confirmBooking : Window
    {
        string comingPackage;
        public confirmBooking(string packageName,string loginName)
        {
            comingPackage = packageName;
            InitializeComponent();

            groupBox.Header = packageName;

            admin_login_name.Text = loginName;

            string login_name = admin_login_name.Text;
            if (login_name != "")
            {
                //that mean loged
                menuAdmin.Visibility = Visibility.Hidden;
                menuSearch.Visibility = Visibility.Visible;
                menuUpdate.Visibility = Visibility.Visible;
                menuDelete.Visibility = Visibility.Visible;
                menuLogout.Visibility = Visibility.Visible;

            }
        }




private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            home myHome = new home(admin_login_name.Text);
            myHome.Show();
            this.Close();
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                string connectionstring = @"Data Source=DESKTOP-EOBFFSQ;Initial Catalog=pptravel;Integrated Security=True";
                SqlConnection sqlcon = new SqlConnection(connectionstring);
                sqlcon.Open();
                string name = Name_box.Text;
                string email = email_box.Text;
                string phone = phone_box.Text;
                string address = address_box.Text;
                string person = person_box.Text;
                string package = comingPackage;
                string date = date_picker.SelectedDate.Value.ToShortDateString();
                string sql = "insert into booking (name,email,phone,address,person,package,date) values ('"+name+ "','" + email + "','" + phone + "','" + address + "','" + person + "','" + package + "','" + date + "')";
                SqlCommand cmd = new SqlCommand(sql, sqlcon);
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.InsertCommand=new SqlCommand(sql, sqlcon);

                adapter.InsertCommand.ExecuteNonQuery();
                cmd.Dispose(); 
                MessageBox.Show("Thank you for your booking, we will send you an email.");
                sqlcon.Close();
            }
            catch(Exception ex) {
                MessageBox.Show("DB error:" + ex.ToString());
            }
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            update pudt = new update(admin_login_name.Text);
            pudt.Show();
            this.Close();
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            delete dt = new delete(admin_login_name.Text);
            dt.Show();
            this.Close();
        }


        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            search srh = new search(admin_login_name.Text);
            srh.Show();
            this.Close();
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {
            MessageBoxResult messageBoxResult = MessageBox.Show("Are you sure?", "Logout Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                logoutsys mylogout = new logoutsys();
                //mylogout.Show();
                this.Close();
            }
        }
    }
}
