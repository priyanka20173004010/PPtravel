﻿ using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PPtravel1
{
    /// <summary>
    /// Interaction logic for search.xaml
    /// </summary>
    public partial class search : Window
    {
        public search(string loginName)
        {
            InitializeComponent();
            admin_login_name.Text = loginName;

            string login_name = admin_login_name.Text;
            if (login_name != "")
            {
                //that mean loged
                menuAdmin.Visibility = Visibility.Hidden;
                menuSearch.Visibility = Visibility.Visible;
                menuUpdate.Visibility = Visibility.Visible;
                menuDelete.Visibility = Visibility.Visible;
                menuLogout.Visibility = Visibility.Visible;

            }
        }


        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            home myHome = new home(admin_login_name.Text);
            myHome.Show();
            this.Close();
        }
        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            update pudt = new update(admin_login_name.Text);
            pudt.Show();
            this.Close();
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            delete dt = new delete(admin_login_name.Text);
            dt.Show();
            this.Close();
        }


        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            search srh = new search(admin_login_name.Text);
            srh.Show();
            this.Close();
        }

        private void search_btn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string connectionstring = @"Data Source=DESKTOP-EOBFFSQ;Initial Catalog=pptravel;Integrated Security=True";
                SqlConnection sqlcon = new SqlConnection(connectionstring);
                sqlcon.Open();

                SqlCommand command;
                SqlDataReader dataReader;
                String sql, Output;
                sql = "select* from booking where CONVERT(varchar,email)='"+email_box.Text+"'";
                command = new SqlCommand(sql,sqlcon);
                dataReader = command.ExecuteReader();

                if (dataReader.Read())
                {
                    Output= "Name:"+dataReader.GetValue(0)+"\n";
                    Output = Output+"Email:" + dataReader.GetValue(1) + "\n";
                    Output = Output + "Phone:" + dataReader.GetValue(2) + "\n";
                    Output = Output + "Address:" + dataReader.GetValue(3) + "\n";
                    Output = Output + "Person:" + dataReader.GetValue(4) + "\n";
                    Output = Output + "Package:" + dataReader.GetValue(5) + "\n";
                    Output = Output + "date:" + dataReader.GetValue(6) + "\n";

                }
                else Output = "Nothing found to show.";

                result_show.Text = Output;
                dataReader.Close();
                command.Dispose();
                sqlcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("DB error:"+ex.ToString());
            }
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {
            MessageBoxResult messageBoxResult = MessageBox.Show("Are you sure?", "Logout Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                logoutsys mylogout = new logoutsys();
                //mylogout.Show();
                this.Close();
            }

        }
    }
}
