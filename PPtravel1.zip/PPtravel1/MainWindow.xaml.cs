﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PPtravel1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
           
            InitializeComponent();
        }

       


        int attempt = 3;
    
        private void button_Click(object sender, RoutedEventArgs e)
        {
            string user_email = textBox.Text;
            string password = passwordBoxx.Password;


            try
            {
                string connectionstring = @"Data Source=DESKTOP-EOBFFSQ;Initial Catalog=pptravel;Integrated Security=True";
                SqlConnection sqlcon = new SqlConnection(connectionstring);
                sqlcon.Open();

                SqlCommand command;
                SqlDataReader dataReader;
                String sql, Output;
                sql = "select* from admin where CONVERT(varchar,user_name)='" + user_email + "' AND password='"+ password + "'";
                command = new SqlCommand(sql, sqlcon);
                dataReader = command.ExecuteReader();

                if (dataReader.Read())
                {
                    //login 
                    home myHome = new home();
                    myHome.Show();
                    this.Close();

                }
                else if (attempt != 0)
                {

                    attempt--;
                    textBox.Text = "";
                    passwordBoxx.Password = "";
                    label3.Content = "Email or Password is invalid , try again";
                }  
                else
                {
                    MessageBox.Show("You attempt 3 times already.");
                    System.Environment.Exit(0);
                }

                dataReader.Close();
                command.Dispose();
                sqlcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("DB error:" + ex.ToString());
            }

        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            label3.Content = "";
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
